function o(t){if(typeof t!="object"||!t)return!1;let e=Object.getPrototypeOf(t);return e===null||e===Object.prototype}export{o as e};
