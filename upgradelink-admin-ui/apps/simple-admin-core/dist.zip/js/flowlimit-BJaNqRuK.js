import{_ as o}from"./flowlimit.vue_vue_type_script_setup_true_lang-D_XKTN5N.js";import"../jse/index-index-Cg1H3Hkl.js";import"./bootstrap-iRyQFocf.js";export{o as default};
