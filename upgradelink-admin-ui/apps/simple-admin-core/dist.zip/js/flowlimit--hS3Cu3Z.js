import{_ as o}from"./flowlimit.vue_vue_type_script_setup_true_lang-DUIsdrNt.js";import"../jse/index-index-BTtpcwdr.js";import"./bootstrap-s22rQ536.js";export{o as default};
