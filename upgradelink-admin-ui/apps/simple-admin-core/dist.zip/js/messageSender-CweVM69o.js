import{v as e}from"./bootstrap-s22rQ536.js";const n=s=>e.post("/sys-api/email/send",s),a=s=>e.post("/sys-api/sms/send",s);export{a,n as s};
